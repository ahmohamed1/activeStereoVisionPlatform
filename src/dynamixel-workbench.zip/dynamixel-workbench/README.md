# Dynamixel workbench packages

For more information, please check the document below.

[ROS Wiki for Dynamixel workbench](http://wiki.ros.org/dynamixel_workbench)
