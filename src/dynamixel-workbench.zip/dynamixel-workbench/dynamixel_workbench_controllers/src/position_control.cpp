/*******************************************************************************
* Copyright 2016 ROBOTIS CO., LTD.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*******************************************************************************/

/* Authors: Taehoon Lim (Darby) */

#include "dynamixel_workbench_controllers/position_control.h"
#include <std_msgs/Float64.h>

PositionControl::PositionControl()
    :node_handle_("")
{
  std::string device_name   = node_handle_.param<std::string>("device_name", "/dev/ttyUSB0");
  uint32_t dxl_baud_rate    = node_handle_.param<int>("baud_rate", 57600);

  uint8_t scan_range        = node_handle_.param<int>("scan_range", 200);

  uint32_t profile_velocity     = node_handle_.param<int>("profile_velocity", 200);
  uint32_t profile_acceleration = node_handle_.param<int>("profile_acceleration", 50);

  dxl_wb_ = new DynamixelWorkbench;

  dxl_wb_->begin(device_name.c_str(), dxl_baud_rate);
  dxl_wb_->scan(dxl_id_, &dxl_cnt_, scan_range);

  initMsg();


  for (int index = 0; index < dxl_cnt_; index++){
        dxl_wb_->jointMode(dxl_id_[index], profile_velocity, profile_acceleration);
        dxl_wb_->itemWrite(dxl_id_[index], "Position_I_Gain", 600);    // Set position I gain to 1000
    }



  initPublisher();

  initServer();

  //////////////////////////////////////////////////////
  motorOneSubscriber = node_handle_.subscribe("/left/pan/move",1,&PositionControl::moveMotorOneCallback,this);
  motorTwoSubscriber = node_handle_.subscribe("/right/pan/move",1,&PositionControl::moveMotorTwoCallback,this);

  motorOnePublisher = node_handle_.advertise<std_msgs::Float64>("/left/pan/angle",10);
  motorTwoPublisher = node_handle_.advertise<std_msgs::Float64>("/right/pan/angle",10);
  rightMotorSpeedPublisher = node_handle_.advertise<std_msgs::Float64>("/right/pan/speed", 10);

}

PositionControl::~PositionControl()
{
  for (int index = 0; index < dxl_cnt_; index++)
    dxl_wb_->itemWrite(dxl_id_[index], "Torque_Enable", 0);
  ros::shutdown();
}

void PositionControl::initMsg()
{
  printf("-----------------------------------------------------------------------\n");
  printf("  dynamixel_workbench controller; position control example             \n");
  printf("-----------------------------------------------------------------------\n");
  printf("\n");

  for (int index = 0; index < dxl_cnt_; index++)
  {
    printf("MODEL   : %s\n", dxl_wb_->getModelName(dxl_id_[index]));
    printf("ID      : %d\n", dxl_id_[index]);
    printf("\n");
  }
  printf("-----------------------------------------------------------------------\n");
}

void PositionControl::initPublisher()
{
  dynamixel_state_list_pub_ = node_handle_.advertise<dynamixel_workbench_msgs::DynamixelStateList>("dynamixel_state", 10);
}

void PositionControl::initServer()
{
  joint_command_server_ = node_handle_.advertiseService("joint_command", &PositionControl::jointCommandMsgCallback, this);
}

///////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
float PositionControl::degree2radian(float degree){
  return (degree * PI / 180);
}

float PositionControl::radian2degree(float radian){
  return (radian * 180 / PI);
}
void PositionControl::moveMotorOneCallback(const std_msgs::Float64& val){

  int32_t goal_position = 0;
  int32_t present_position = 0;

  float valueRadian = PositionControl::degree2radian(val.data);
  goal_position = dxl_wb_->convertRadian2Value(1, valueRadian);

  bool ret = dxl_wb_->goalPosition(1, goal_position);

}


void PositionControl::moveMotorTwoCallback(const std_msgs::Float64& val){

  int32_t goal_position = 0;
  int32_t present_position = 0;

  float valueRadian = PositionControl::degree2radian(val.data);
  goal_position = dxl_wb_->convertRadian2Value(2, valueRadian);

  bool ret = dxl_wb_->goalPosition(2, goal_position);
}

  ///////////////////////// keep publishing the angle only
void PositionControl::publishMotorOneAngle(){
  std_msgs::Float64  motorOneAngleDegree;
  float degree = map(dxl_wb_->itemRead(dxl_id_[1], "Present_Position"), 0, 4096, -180, 180);
  motorOneAngleDegree.data = degree;
  motorOnePublisher.publish(motorOneAngleDegree);
  // std::cout<< dxl_wb_->itemRead(dxl_id_[0], "Present_Position") << std::endl;
}

void PositionControl::publishMotorTwoAngle(){

  std_msgs::Float64  motorTwoAngleDegree;
  float degree = map(dxl_wb_->itemRead(dxl_id_[1], "Present_Position"), 0, 4096, -180, 180);
  motorTwoAngleDegree.data = degree;
  motorTwoPublisher.publish(motorTwoAngleDegree);
  std_msgs::Float64 speed;
  speed.data = dxl_wb_->itemRead(dxl_id_[1], "Present_Velocity");
  rightMotorSpeedPublisher.publish(speed);

}


float PositionControl::map(float x, float in_min, float in_max, float out_min, float out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

///////////////////////////////////////////////////////////////////
void PositionControl::dynamixelStatePublish()
{
  dynamixel_workbench_msgs::DynamixelState     dynamixel_state[dxl_cnt_];
  dynamixel_workbench_msgs::DynamixelStateList dynamixel_state_list;
  for (int index = 0; index < dxl_cnt_; index++)
  {
    dynamixel_state[index].model_name          = std::string(dxl_wb_->getModelName(dxl_id_[index]));
    dynamixel_state[index].id                  = dxl_id_[index];
    dynamixel_state[index].torque_enable       = dxl_wb_->itemRead(dxl_id_[index], "Torque_Enable");
    dynamixel_state[index].present_position    = dxl_wb_->itemRead(dxl_id_[index], "Present_Position");
    dynamixel_state[index].goal_position       = dxl_wb_->itemRead(dxl_id_[index], "Goal_Position");
    dynamixel_state[index].moving              = dxl_wb_->itemRead(dxl_id_[index], "Moving");
    dynamixel_state[index].present_velocity    = dxl_wb_->itemRead(dxl_id_[index], "Present_Velocity"); // "Present_Velocity" or "Present_Speed"
    dynamixel_state[index].goal_velocity       = dxl_wb_->itemRead(dxl_id_[index], "Goal_Velocity");    // "Goal_Velocity" or "Moving_Speed"
    float radian = map(dxl_wb_->itemRead(dxl_id_[index], "Present_Position"), 0, 4096, -180, 180);
    motorAnglesDegrees[index] = radian ; //dxl_wb_->itemRead(dxl_id_[index], "Present_Position"); //PositionControl::radian2degree(radian);
    std::cout << motorAnglesDegrees[index]  << "         ";
    dynamixel_state_list.dynamixel_state.push_back(dynamixel_state[index]);
  }
  std::cout << std::endl;
  dynamixel_state_list_pub_.publish(dynamixel_state_list);

}


void PositionControl::controlLoop()
{

  dynamixelStatePublish();
  publishMotorOneAngle();
  publishMotorTwoAngle();

}

bool PositionControl::jointCommandMsgCallback(dynamixel_workbench_msgs::JointCommand::Request &req,
                                              dynamixel_workbench_msgs::JointCommand::Response &res)
{
  int32_t goal_position = 0;
  int32_t present_position = 0;

  if (req.unit == "rad")
  {
    if (req.id == 4)
      {
        float angle = req.goal_position;
        int value = map(angle, -150, 150, 0, 2025);
        goal_position = value;
        printf("goal position: %f   ,  value %i\n", angle, goal_position);
      }else{
        goal_position = dxl_wb_->convertRadian2Value(req.id, req.goal_position);
      }
  }
  else if (req.unit == "raw")
  {
    goal_position = req.goal_position;
  }
  else
  {
    goal_position = req.goal_position;
  }

  bool ret = dxl_wb_->goalPosition(req.id, goal_position);

  res.result = ret;
}

int main(int argc, char **argv)
{
  // Init ROS node
  ros::init(argc, argv, "position_control");
  PositionControl pos_ctrl;

  ros::Rate loop_rate(20);

  while (ros::ok())
  {
    pos_ctrl.controlLoop();
    ros::spinOnce();
    loop_rate.sleep();
  }

  return 0;
}
